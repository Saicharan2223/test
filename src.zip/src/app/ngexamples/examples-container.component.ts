import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-examples-container',
  templateUrl: './examples-container.component.html',
  styles: [
  ]
})
export class ExamplesContainerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
