export class Person{
    constructor(public uid:number,public uname:string, public uemail:string,public udob:string,public ugender:string,public ucountry:string){}
}