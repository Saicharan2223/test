export class User{
    constructor(public uid:string,public uname:string, public urole:string){}
}