import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-video-demo',
  template: `
    <p>
      video-demo works!
    </p>
  `,
  styles: [
  ]
})
export class VideoDemoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
