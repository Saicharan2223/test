import { platformBrowserDynamic } from "@angular/platform-browser-dynamic";
import {AppModule} from "./app/app.module";
platformBrowserDynamic().bootstrapModule(AppModule)
//const myString="ABC"
//const array1=[10,3]
//console.log(array1)
//array1.push(50)
//console.log(array1)
//let y=[...array1,60]
//console.log(y)
//console.log(array1)
//let m=[...array1.slice(0,1),...array1.slice(2)]//delete
//console.log(m)
//console.log(array1)
//let p=[...array1.slice(0,1),999,...array1.slice(2)]//update
//console.log(p)